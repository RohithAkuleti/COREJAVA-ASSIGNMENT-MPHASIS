package com.rohith.problem1;

import java.util.Scanner;

public class EvenDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the value of n is :");
		int n=scan.nextInt();
		
		
		int i;
		System.out.println("Even numbers from 1 to "+n+" are:");
		for(i=1;i<=n;i++) {
			//number%2 =0 means it is an even number
			if(i%2==0) {
				System.out.println(i);
			}
		}
		

	}

}
