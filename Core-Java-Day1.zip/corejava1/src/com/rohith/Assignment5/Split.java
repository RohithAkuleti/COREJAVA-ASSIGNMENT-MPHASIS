package com.rohith.Assignment5;

public class Split {

	public static void main(String[] args) {
		String str="23 + 45 - ( 343 / 12 )";
		String[] arrOfstr= str.split(" ");
		System.out.println("number of substring: "+arrOfstr.length);
		
		for(int i=0;i<arrOfstr.length;i++)
		{
			System.out.println("str["+i+"]:"+arrOfstr[i]);
		}
		
	}

}
