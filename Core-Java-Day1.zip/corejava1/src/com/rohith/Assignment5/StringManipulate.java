package com.rohith.Assignment5;


import java.io.*;
import java.util.Scanner;


public class StringManipulate {

	public static void main(String[] args) {
		char ch;
		String str="JAVA is simple",nstr=" ";
		
		for(int i=0;i<str.length();i++) {
			ch=str.charAt(i);
			nstr=ch+nstr; // add each character in front of existing string
			
			
		}
		System.out.println(nstr);
		str.toLowerCase();
		str.toUpperCase();
		str.charAt(1);
		str.split(str);
		
		System.out.println(str.toLowerCase());
		System.out.println(str.toUpperCase());
		System.out.println(str.charAt(1));
		System.out.println(str.length());
		System.out.println(str);
		

	}

}
