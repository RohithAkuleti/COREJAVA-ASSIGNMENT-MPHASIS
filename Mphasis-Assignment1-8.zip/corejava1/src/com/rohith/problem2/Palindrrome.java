package com.rohith.problem2;
 
import java.util.Locale;

//Java Program to check Whether the String is Palindrome
//or Not

//Main class
public class Palindrrome {
	// Method 1
		// Returns true if string is a palindrome
		static boolean isPalindrome(String str)
		{

			int i = 0, j = str.length() - 1;  // Pointers pointing to the begining and the end of the string

			while (i < j) {   // While there are characters to compare

				// If there is a mismatch
				if (str.charAt(i) != str.charAt(j))
					return false;

				// Increment first pointer and
				// decrement the other
				i++;
				j--;
			}

			// Given string is a palindrome
			return true;
		}

		// Main driver method
		public static void main(String[] args)
		{
				String str = "RACEcar";
				
				int n =str.length();
				System.out.println("the length of string is:"+n);
		
			//Change strings to Uppercase
			str = str.toUpperCase();
			
			System.out.println("string in uc :"+ str.toUpperCase(Locale.ROOT));
			// For string 1
			System.out.print("String 1 :");
			

			if (isPalindrome(str))
				System.out.print("It is a palindrome");
			else
				System.out.print("It is not a palindrome");

			
		}
	}
