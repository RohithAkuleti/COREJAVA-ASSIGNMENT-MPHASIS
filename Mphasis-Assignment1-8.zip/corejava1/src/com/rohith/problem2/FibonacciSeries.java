package com.rohith.problem2;

public class FibonacciSeries {

//Using  For Loop

	public static void main(String[] args) 
	{
		// Set it to the number of elements you want in the Fibonacci Series
		 int n = 13; //maxNumber
		 int n1 = 2; //previousNumber
		 int n2 = 1; //next number
		 
	        System.out.print("Fibonacci Series of "+n+" numbers:");

	        for (int i = 1; i <= n; ++i)
	        {
	            System.out.print(n2+" ");
	            /* On each iteration, we are assigning second number
	             * to the first number and assigning the sum of last two
	             * numbers to the second number
	             */

	      
	            int sum = n1 + n2; // sum=2+1=3  
	            n1= n2;  //n2 value goes to n1
	            n2 = sum;  //sum value goes to n2 
	        }
	}
}