package com.rohith.Framework6;

import java.util.ArrayList;
 
public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> list = new ArrayList<>();
		list.add("rr");
		list.add("rrr");
		list.add("rrad");
		list.add("rassr");
		list.add("rjjjr");
		list.add("rdytr");
		
		if (list.contains("rr"))
			System.out.println("exit in array");
		else
			System.out.println("not exits");
	}

}
